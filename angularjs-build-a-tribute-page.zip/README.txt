A Pen created at CodePen.io. You can find this one at http://codepen.io/danomah/pen/oZwxPL.

 Using AngularJS to build up tribute page.